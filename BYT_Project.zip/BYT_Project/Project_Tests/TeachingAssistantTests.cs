﻿using NUnit.Framework;
using System;
using BYT_Project;
using System.IO;

namespace BYT_Project.Tests
{
    [TestFixture]
    public class TeachingAssistantTests
    {
        [SetUp]
        public void SetUp()
        {
           
            var teachingAssistantsListField = typeof(TeachingAssistant).GetField("teachingAssistantsList", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.NonPublic);
            teachingAssistantsListField.SetValue(null, new List<TeachingAssistant>());

          
            if (File.Exists("teachingAssistantsTest.xml"))
            {
                File.Delete("teachingAssistantsTest.xml");
            }
        }

        [Test]
        public void TestGetCorrectTeachingAssistantInformation()
        {
            var ta = new TeachingAssistant(1, 3);
            Assert.That(ta.TeachingAssistantID, Is.EqualTo(1));
            Assert.That(ta.Experience, Is.EqualTo(3));
        }

        [Test]
        public void TestExceptionForInvalidTeachingAssistantID()
        {
            var ex = Assert.Throws<ArgumentException>(() => new TeachingAssistant(-1, 3));
            Assert.That(ex.Message, Is.EqualTo("Teaching Assistant ID must be positive."));
        }

        [Test]
        public void TestExceptionForNegativeExperience()
        {
            var ex = Assert.Throws<ArgumentException>(() => new TeachingAssistant(1, -1));
            Assert.That(ex.Message, Is.EqualTo("Experience cannot be negative."));
        }

        [Test]
        public void TestSaveAndLoadTeachingAssistants()
        {
            var ta1 = new TeachingAssistant(1, 3);
            var ta2 = new TeachingAssistant(2, 5);

            TeachingAssistant.SaveTeachingAssistants("teachingAssistantsTest.xml");
            var success = TeachingAssistant.LoadTeachingAssistants("teachingAssistantsTest.xml");

            Assert.That(success, Is.True);  
            Assert.That(TeachingAssistant.TeachingAssistantsList.Count, Is.EqualTo(2));  
        }

        [Test]
        public void TestPersistencyAfterLoad()
        {
            var ta = new TeachingAssistant(1, 3);
            TeachingAssistant.SaveTeachingAssistants("teachingAssistantsTest.xml");

            
            TeachingAssistant.LoadTeachingAssistants("teachingAssistantsTest.xml");

            Assert.That(TeachingAssistant.TeachingAssistantsList.Count, Is.GreaterThan(0));  
        }
    }
}
